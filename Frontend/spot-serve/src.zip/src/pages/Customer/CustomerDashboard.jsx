// src/pages/Customer/CustomerDashboard.jsx
import React, { useEffect, useState } from "react";
import api from "../../api"; // ✅ corrected path
import { getUser, logout } from "../../utils/auth"; // ✅ corrected path

const CustomerDashboard = () => {
  const [vehicles, setVehicles] = useState([]);
  const [services, setServices] = useState([]);
  const user = getUser();

  // Fetch user's vehicles
  const fetchVehicles = async () => {
    try {
      const response = await api.get(`/api/customer/${user.id}/vehicles`);
      setVehicles(response.data);
    } catch (error) {
      console.error("Error fetching vehicles:", error);
    }
  };

  // Fetch user's service history
  const fetchServiceHistory = async () => {
    try {
      const response = await api.get(`/api/customer/${user.id}/services`);
      setServices(response.data);
    } catch (error) {
      console.error("Error fetching service history:", error);
    }
  };

  useEffect(() => {
    if (user && user.id) {
      fetchVehicles();
      fetchServiceHistory();
    }
  }, []);

  const handleLogout = () => {
    logout();
    window.location.href = "/";
  };

  return (
    <div className="dashboard-container" style={styles.container}>
      <div style={styles.header}>
        <h2>Welcome, {user?.name || "Customer"}</h2>
        <button onClick={handleLogout} style={styles.logoutBtn}>
          Logout
        </button>
      </div>

      <div style={styles.section}>
        <h3>Your Vehicles</h3>
        {vehicles.length === 0 ? (
          <p>No vehicles added yet.</p>
        ) : (
          <ul>
            {vehicles.map((v) => (
              <li key={v.id}>
                {v.vehicleName} — {v.vehicleNumber}
              </li>
            ))}
          </ul>
        )}
        <button style={styles.addBtn}>+ Add Vehicle</button>
      </div>

      <div style={styles.section}>
        <h3>Service History</h3>
        {services.length === 0 ? (
          <p>No service history found.</p>
        ) : (
          <ul>
            {services.map((s) => (
              <li key={s.id}>
                {s.serviceType} — {s.status} — {new Date(s.date).toLocaleDateString()}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

// Inline CSS styles
const styles = {
  container: {
    padding: "20px",
    fontFamily: "Poppins, sans-serif",
  },
  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: "20px",
  },
  logoutBtn: {
    background: "#ff5555",
    color: "#fff",
    border: "none",
    padding: "8px 16px",
    borderRadius: "6px",
    cursor: "pointer",
  },
  section: {
    background: "#f9f9f9",
    padding: "15px",
    borderRadius: "8px",
    marginBottom: "20px",
  },
  addBtn: {
    marginTop: "10px",
    background: "#007bff",
    color: "#fff",
    border: "none",
    padding: "8px 12px",
    borderRadius: "6px",
    cursor: "pointer",
  },
};

export default CustomerDashboard;
