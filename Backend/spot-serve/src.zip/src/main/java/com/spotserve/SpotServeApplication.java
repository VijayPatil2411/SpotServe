package com.spotserve;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class SpotServeApplication {
public static void main(String[] args) {
SpringApplication.run(SpotServeApplication.class, args);
}
}
